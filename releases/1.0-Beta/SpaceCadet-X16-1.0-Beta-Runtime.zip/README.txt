Space Cadet - original presentation on X16 -- 1.0 Beta

Extract into its own writable folder. Put x16emu.exe and its matching rom.bin
in the parent folder. Put the unopened CmdrX_Cadet_0.3.1_Development.zip in
the game folder or its parent, then double-click RUN-WINDOWS.bat.
PowerShell 5.1 or newer is required. No compiler or manual asset copying is needed.
The launcher validates assets and imports missing/damaged files automatically.
After successful setup the local ZIP is needed only for repair.
Use separate folders for the two editions; their presentation files differ.

Flippers: Z and /. Plunger: hold/release Space. New game: F2.
Music: M. Exit: Escape.

This is an X16 adaptation, not the Windows executable. Original playfield,
audio, emulator and ROM are not included. Supply the local asset ZIP yourself.
Original presentation is imported without the 2D artwork patch.
Engine source commit: 9534fb8ed127092b0e9580ab75bfaf5d010e9b94
Specification commit: 898276b21c124afddbb242fb4dba0ff933feb049
Both editions use identical beta PRG and overlay bytes from the verified reference.
Original mode uses that same current engine, not the older 0.3.1 engine binary.

The specs/ folder contains the human and machine engine specifications.
It is documentation; JSON reference data includes geometry and policy excerpts.
No standalone source/build files or nested archives are included.

Known limitations include occasional frame-budget overruns and incomplete rules.
Windows interactive testing has not been performed for this package.
See the adjacent release validation report for exactly what was tested.

Licensing: LICENSE covers new code; ENGINE-THIRD-PARTY-LICENSE credits the
recovered engine. Original Space Cadet artwork/audio belong to their respective
rights holders and are not relicensed here. Microsoft/Maxis/Cinematronics
Space Cadet source reference: https://github.com/k4zmu2a/SpaceCadetPinball
