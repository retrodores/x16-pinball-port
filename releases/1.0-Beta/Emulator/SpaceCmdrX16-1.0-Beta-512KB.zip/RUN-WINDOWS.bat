@echo off
setlocal
cd /d "%~dp0" || exit /b 1
if not exist "..\x16emu.exe" goto emulator
if not exist "..\rom.bin" goto emulator
for %%F in (CADET.MEC RINGS2.BIN STARTFX.BIN MSGFONT.BIN RINGS.BIN CADET.PRG CADET.PHY CADET.RUL FONT.BIN MAP.BIN TILES.BIN PAL.BIN SPRITES.BIN UI.BIN GEOM0.BIN GEOM1.BIN GEOM2.BIN MUSIC0.BIN MUSIC1.BIN PCM0.BIN PCM1.BIN PCM2.BIN DYN0.BIN DYN1.BIN DYN2.BIN DYN3.BIN DEPTH00.BIN DEPTH01.BIN DEPTH02.BIN DEPTH03.BIN DEPTH04.BIN DEPTH05.BIN DEPTH06.BIN DEPTH07.BIN DEPTH08.BIN) do if not exist "%%F" goto missing
"..\x16emu.exe" -rom "..\rom.bin" -c02 -mhz 8 -ram 512 -fsroot . -prg CADET.PRG -run -scale 2
set "RUN_RESULT=%errorlevel%"
if not "%RUN_RESULT%"=="0" pause
exit /b %RUN_RESULT%
:missing
echo A required game file is missing. Extract the complete runtime ZIP again.
pause
exit /b 1
:emulator
echo Place x16emu.exe and its matching rom.bin in the parent folder.
pause
exit /b 1
