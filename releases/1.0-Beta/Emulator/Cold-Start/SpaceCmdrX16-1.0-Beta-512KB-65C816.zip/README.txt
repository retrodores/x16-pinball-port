Space CmdrX16 1.0 Beta (512 KB, 65C816)

Run PINBALL.PRG from this folder. Requires 512 KB of banked RAM. The embedded specifications document
the original build names. The package launcher uses the filename above.

Extract into its own folder. Put x16emu.exe and matching rom.bin in the
parent folder, then double-click RUN-WINDOWS.bat. All game assets are included.

Flippers: Z and /. Plunger: hold and release Space. Quit to BASIC: Q or Escape.
F3 or idle starts the demo. F2 or a play control takes over. M toggles music.
The center lamps show rank and the first-rank Target Practice and Launch
Training missions. Demo flippers respond to the ball's approach.
The upper pane shows Player 1. Short messages appear in the lower pane.

Both panes use the original proportional message glyphs. The score and BALL counters use their original numeral sprites.
The center rings sparkle during the opening.
This is a development preview. The broader mission system is incomplete
and some frames exceed the 133,333-cycle target. The embedded engine
specifications describe the verified baseline. Runtime source commit ae79024823cbe7a7d555477523e4be9ea459be22.

LICENSE covers the new code. Original game artwork, audio, and the
PBMSG_FT letterforms are separate resources. See ENGINE-THIRD-PARTY-LICENSE
and https://github.com/k4zmu2a/SpaceCadetPinball for engine attribution.
Specification commit 898276b21c124afddbb242fb4dba0ff933feb049.

The opening animates the playfield lamps before the first ball is served.
F2 starts a new game or skips an active opening.
The installed opening sound plays on cold start and F2.
F2 clears the screen and starts the lamps before loading the opening sound.

Both flag spinners react to a passing ball. The red X flashes during the opening.
The larger Time Warp mission is still pending.

Use Up Arrow to nudge. Three close nudges trigger tilt. Clear the first three drop targets for a four-second spinner boost.
The upper status panel reports tilt, boost, and wormhole visits.
