@echo off
setlocal
cd /d "%~dp0" || exit /b 1
if not exist "..\x16emu.exe" goto emulator
if not exist "..\rom.bin" goto emulator
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY-2D.ps1"
if errorlevel 1 goto failed
"..\x16emu.exe" -rom "..\rom.bin" -c02 -mhz 8 -ram 512 -fsroot . -prg CADET.PRG -run -scale 2
set "RUN_RESULT=%errorlevel%"
if not "%RUN_RESULT%"=="0" pause
exit /b %RUN_RESULT%
:failed
echo Asset setup failed. Read the error above. Keep the 0.3.1 ZIP zipped.
pause
exit /b 1
:emulator
echo Place x16emu.exe and its matching rom.bin in the parent folder.
pause
exit /b 1
