$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$expected = @'
{
  "MAP.BIN": "5e13fdd9f11ff762f3656b8685296a778c78d995a91439f5546c7f7c46780e7f",
  "TILES.BIN": "0f5cbf23dd41122d60da927c68899a55c27f51da0f2159356442d23fe4905d05",
  "PAL.BIN": "8f94a15c67fae3f52b4da0ce6e84b05cac2891146167c87da486054d57a5192b",
  "SPRITES.BIN": "b69983fccf9c13fcd2294a8284f9bd37a85b3af75a2474adf48682b1f844cede",
  "UI.BIN": "3756b6903d2c1aefe03f0d01fe108d0f11859d97f74654a7abffdfb4a9f14251",
  "GEOM0.BIN": "fae9acb796bc25f6afe48e98db849c38071671fd214f6e08ac0f2c25713b1192",
  "GEOM1.BIN": "6598497fa23946b59d8c952f7ac2e53b0c3ce0da1bff72ffe2cd9f3cfd919a35",
  "GEOM2.BIN": "a19049d8fa2795b880705e23051745cc7648eec38166d9db91cb5e3097f860ca",
  "MUSIC0.BIN": "a725d34230c7eb2f6d0ddad3139807682dbeb0ae9d0fd3e4054aff829e544706",
  "MUSIC1.BIN": "5d7b84eb6f4246dffee695330247f45b8551d7701a32bc168feaabc5c078cfa9",
  "PCM0.BIN": "6f4f91a14d9b61fbdd4698ee652188a7299ff79d28e594460d788bf9327c7dfd",
  "PCM1.BIN": "b03f7f82ad07a442620f2b10ab130d1d5467ad111739fc7aca26ba76ddde3b73",
  "PCM2.BIN": "e98cb5cf4ce2dcd9c481fa31a4d9bc6e683c335b60d99480bb5694eb92f64e7b",
  "DEPTH00.BIN": "5cdeb8f62c4c3d05c913b10c4867dcb979bf5676c6c0544be709051cf30fbcee",
  "DEPTH01.BIN": "ee82683f10ee9946e434110341075894cbf5186f7bce86d06fb92ecb89c4cedf",
  "DEPTH02.BIN": "b3d9e7e58e3f77d5b3296681c87591fba0dfd166b897934eb485f1584ff50d73",
  "DEPTH03.BIN": "02b21af3bdc3c3dc817e629fe8abc10c8684d2759414ac583d05a45883ee5893",
  "DEPTH04.BIN": "3952176ba429294da837bdb398b4c615096cb2c189892c91e9068957e506afdb",
  "DEPTH05.BIN": "9fe7e6b81247c064afba092bafb617419db9383681627f73cd3c29c7c81c1b1d",
  "DEPTH06.BIN": "2e19f5b0b20bb83e7659db8f197cb82006bc6edcc126d6a239c99a5c70be6dba",
  "DEPTH07.BIN": "7f7979831bb7b83421d5395562ed896b99488f1a10d640a3b0df80b12633a2c2",
  "DEPTH08.BIN": "507e6af35c651824d100f1f0659f07544b3beb1bcc84abad4578f014ab565c32",
  "DYN0.BIN": "91ff6f13d5f400003a456c17a3af74a21b9cac98db6c0785f0052c0dd11b64fd",
  "DYN1.BIN": "6b2fe859745b70c27abcb0e665cb542f0aab9be9649daef76c816d4d00907d03",
  "DYN2.BIN": "48bbd0ed2fe044593b8237f818d4652c11cb481baa982bb70ab253a03aa96232",
  "DYN3.BIN": "89e5280efbf3b730d4ddf9617a2097553e1645fa5909b4275c0d98fb8c62486d"
}
'@ | ConvertFrom-Json
$isCmdr = $true
$patch = $null
if ($isCmdr) { $patch = Get-Content -LiteralPath '2D-PATCH.json' -Raw | ConvertFrom-Json }
function Digest([byte[]]$bytes) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
$repair = @()
foreach ($asset in $expected.PSObject.Properties) {
    $name = $asset.Name
    $ok = $false
    if (Test-Path -LiteralPath $name -PathType Leaf) {
        $hash = (Get-FileHash -LiteralPath $name -Algorithm SHA256).Hash
        $ok = $hash -eq $asset.Value
        if ($isCmdr -and $patch.PSObject.Properties[$name]) { $ok = $ok -or ($hash -eq $patch.$name.after) }
    }
    if (-not $ok) { $repair += $name }
}
if ($repair.Count) {
    $archive = Join-Path $PSScriptRoot 'CmdrX_Cadet_0.3.1_Development.zip'
    if (-not (Test-Path -LiteralPath $archive -PathType Leaf)) { $archive = Join-Path (Split-Path $PSScriptRoot -Parent) 'CmdrX_Cadet_0.3.1_Development.zip' }
    if (-not (Test-Path -LiteralPath $archive -PathType Leaf)) { throw 'First setup or repair needs CmdrX_Cadet_0.3.1_Development.zip in this folder or its parent.' }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($archive)
    $prepared = @{}
    try {
        foreach ($name in $repair) {
            $entries = @($zip.Entries | Where-Object { $_.FullName -ceq $name })
            if ($entries.Count -ne 1) { throw "Missing or duplicate asset: $name" }
            $stream = $entries[0].Open(); $memory = New-Object System.IO.MemoryStream
            try { $stream.CopyTo($memory); $bytes = $memory.ToArray() }
            finally { $stream.Dispose(); $memory.Dispose() }
            if ((Digest $bytes) -ne $expected.$name) { throw "Wrong or damaged asset in ZIP: $name" }
            $prepared[$name] = $bytes
        }
    } finally { $zip.Dispose() }
    foreach ($name in $prepared.Keys) { [System.IO.File]::WriteAllBytes((Join-Path $PSScriptRoot $name), $prepared[$name]) }
}

$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$patch = Get-Content -LiteralPath '2D-PATCH.json' -Raw | ConvertFrom-Json
$prepared = @{}
foreach ($asset in $patch.PSObject.Properties) {
    $name = $asset.Name
    if ($name -cnotmatch '\A(?:MAP|TILES|DYN[0-3])\.BIN\z') {
        throw "Unexpected 2D patch target: $name"
    }
    $spec = $asset.Value
    $path = Join-Path $PSScriptRoot $name
    $current = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
    if ($current -eq $spec.after) { continue }
    if ($current -ne $spec.before) {
        throw "$name differs from the expected 0.3.1 version. The launcher will try the 0.3.1 ZIP if it is available."
    }
    $bytes = [System.IO.File]::ReadAllBytes($path)
    foreach ($entry in $spec.writes) {
        $offset = [int]$entry[0]
        $hex = [string]$entry[1]
        for ($i = 0; $i -lt $hex.Length; $i += 2) {
            $bytes[$offset + [int]($i / 2)] = [Convert]::ToByte($hex.Substring($i, 2), 16)
        }
    }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { $digest = [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-', '') }
    finally { $sha.Dispose() }
    if ($digest -ne $spec.after) { throw "$name failed verification." }
    $prepared[$path] = $bytes
}
foreach ($path in $prepared.Keys) {
    $temporary = "$path.2d.tmp"
    try {
        [System.IO.File]::WriteAllBytes($temporary, $prepared[$path])
        [System.IO.File]::Copy($temporary, $path, $true)
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary }
    }
}
