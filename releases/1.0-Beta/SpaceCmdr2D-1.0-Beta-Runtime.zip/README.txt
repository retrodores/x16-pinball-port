2D Pinball - Space CmdrX16 -- 1.0 Beta

ALL GAME ASSETS ARE INCLUDED AND READY.
Extract this ZIP into its own folder and double-click RUN-WINDOWS.bat.
Put x16emu.exe and its matching rom.bin in the parent folder.
No other asset ZIP, import, patch, PowerShell or build tools are needed.
The emulator and ROM are the only external prerequisites.

Use separate folders for the two editions.
Flippers: Z and /. Plunger: hold/release Space. New game: F2.
Music: M. Exit: Escape.

Engine source commit: 9534fb8ed127092b0e9580ab75bfaf5d010e9b94
Specification commit: 898276b21c124afddbb242fb4dba0ff933feb049
Human and machine-readable engine specifications are in specs/.
This package contains the complete game runtime, not standalone game/build source.
The machine reference documentation includes geometry and policy excerpts.

Linux emulator smoke tests passed at 512 KB and 2048 KB with these game bytes.
Windows interactive testing has not been performed. Occasional frame-budget
overruns and incomplete rules remain; see the release validation report.

LICENSE covers new code. ENGINE-THIRD-PARTY-LICENSE credits the recovered engine.
Original Space Cadet artwork/audio belong to their respective rights holders
and are not relicensed under the engine's MIT notice.
Source reference: https://github.com/k4zmu2a/SpaceCadetPinball
