SpaceCadet-X16 - GTR3QQ Native Music Preview (2 MB)

Extract into a new folder. Double-click RUN-WINDOWS.bat with x16emu.exe and
its matching rom.bin in the parent folder. The launcher selects 65C02,
8 MHz and 2048 KB RAM. M toggles the music. Escape exits.

This development preview plays the YM2151, VERA PSG and stereo PCM parts
of Pinball_R6.zsm with live game effects. Use headphones or stereo speakers.
The soundtrack is resident in banked RAM. Keep Attract Preview 3 for
512 KB configurations. Some frames exceed the 133,333-cycle budget.

Source commit d21625e835cec5132cd9315c5ada5e95de2c59e6
The bundled engine specifications describe the Attract Preview 3 baseline.
See MUSIC-CREDITS.txt for the soundtrack license and source.
