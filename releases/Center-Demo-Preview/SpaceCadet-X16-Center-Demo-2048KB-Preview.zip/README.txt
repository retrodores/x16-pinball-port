SpaceCadet-X16 - Center and Demo Preview (2048 KB)

Extract into its own folder. Put x16emu.exe and matching rom.bin in the
parent folder, then double-click RUN-WINDOWS.bat. All game assets are included.

F3 or idle starts the demo. F2 or a play control takes over. M toggles music.
The center lamps show rank and the first-rank Target Practice and Launch
Training missions. Demo flippers respond to the ball's approach.
The upper pane shows Player 1. Short messages appear in the lower pane.

This cover build brings the game effects forward by approximately 6 dB.
This is a development preview. The broader mission system is incomplete
and some frames exceed the 133,333-cycle target. The embedded engine
specifications describe the verified baseline. Runtime source commit 77c574bffd497887cfea239167109fb3a54ebc65.
