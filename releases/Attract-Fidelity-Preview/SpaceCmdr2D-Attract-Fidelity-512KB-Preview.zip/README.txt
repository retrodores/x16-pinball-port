SpaceCmdr2D - Attract Fidelity Preview (512 KB)

Extract into its own folder. Put x16emu.exe and matching rom.bin in the
parent folder, then double-click RUN-WINDOWS.bat. All game assets are included.

Flippers: Z and /. Plunger: hold and release Space. Exit: Escape.
F3 or idle starts the demo. F2 or a play control takes over. M toggles music.
The center lamps show rank and the first-rank Target Practice and Launch
Training missions. Demo flippers respond to the ball's approach.
The upper pane shows Player 1. Short messages appear in the lower pane.

Both panes use the original proportional message glyphs. The score and BALL counters use their original numeral sprites.
The center rings sparkle during the opening.
This is a development preview. The broader mission system is incomplete
and some frames exceed the 133,333-cycle target. The embedded engine
specifications describe the verified baseline. Runtime source commit a65c79437e02d5f8095949b7b30eed6a7b0e58c3.

LICENSE covers the new code. Original game artwork, audio, and the
PBMSG_FT letterforms are separate resources. See ENGINE-THIRD-PARTY-LICENSE
and https://github.com/k4zmu2a/SpaceCadetPinball for engine attribution.
Specification commit 898276b21c124afddbb242fb4dba0ff933feb049.
