2D Pinball - Space CmdrX16 Christmas Edition - Carol of the Bells - 1.0

Requires a Commander X16 with a 65C02 at 8 MHz and 2 MB of banked RAM.
Windows: place x16emu.exe and its matching rom.bin together. Extract this
ZIP into a folder directly beneath them. Double-click RUN-WINDOWS.bat.
X16 BASIC: from the extracted game directory, LOAD"PINBALL.PRG",8,1 then RUN.

Hold Space and release to launch. Z and / flip. F2 starts a new game.
F3 starts the demo. M toggles music. Q or Esc returns to BASIC.

CAROL.ZSM is a 74.2-second melody-first rock arrangement of Carol of the Bells.
Listen for the higher answer around 0:28, the return around 0:42, and
the final chord at 1:10. Table lamps follow the score and laser sweeps.
Candy-striped flippers, peppermint bumpers, a silver bauble ball and a
brass-and-green plunger carry the cabinet theme onto the playfield.
The bumper jewels show their upgrade level and flash when struck.

Some frames exceed 133,333 cycles.
See MUSIC-CREDITS.txt for the music and LICENSE and ENGINE-THIRD-PARTY-LICENSE
for code notices. Original table artwork, sounds and PBMSG_FT letterforms
are separate game resources. Original engine reconstruction:
https://github.com/k4zmu2a/SpaceCadetPinball
Base engine specification revision: 898276b21c124afddbb242fb4dba0ff933feb049.
